/*ガラケー配列[7][8]　[age][year]*/
var gala =[[77.5,53.9,52.9,31.5,25.1,19.9,19.6,25.4],[87.7,69.3,60.2,49.3,41.9,31.5,26.3,25.5],[94.4,82.2,74.1,62.7,58.9,49.2,40,36],[95.9,90.2,84.3,76.8,68.2,55.9,48.1,41.5],[95.9,93.1,90.2,85.7,78.1,72.9,63.6,53.7],[85.1,92.5,89.6,82.9,84.2,79.5,74.2,68.1],
	[86.9,87,84.8,70.3,71.1,66,63.1,65.8]];
  
/*スマホ配列[7][8] [age][year]*/
var sma =[[51.4,79.7,89.8,94.5,98.4,99.4,97.1,95.9],[41.3,72.7,84.9,92.4,94.2,96.2,97.4,97.2],[34.9,63.4,78.1,83.8,88.8,90.7,94.1,95],[38.2,58.5,73.2,75,83.9,86.5,88.3,89.7],[22.3,39.4,56,47.7,64.2,63.5,69.5,78.3],[12.2,25.3,41.4,28,36.7,38.4,44.9,55.4],
	[11,20.2,30.2,20.8,31.9,28.6,31.5,35.5]];

var ageslider=0;//ageスライダーの現在位置を記録
var yearslider=0;//yearスライダーの現在位置を記録

$(function () {
    $('#ageSlider').slider({
        max: 6,
        min: 0,
        orientation: "vertical",
        step: 1,
        value: 0,
        range: "min",

        slide: function (select, handleIndex) {//ageスライダーが動いた時にこの中が実行される
		
            ageslider = handleIndex.value;//スライダーの現在位置を記録
			
			var showAge = (handleIndex.value+2)*10;//表示用にスライダーの数値を改造（[0~6]→[20~80]）
			document.getElementById("age").innerText = "age : " + showAge;//表示
			
			/*普及率の数字が描画される円の面積に反映されるようにする計算*/
			var gala_Menseki_Kara_Chokkei = 2*Math.sqrt(gala[ageslider][yearslider])/Math.PI;
			var sma_Menseki_Kara_Chokkei = 2*Math.sqrt(sma[ageslider][yearslider])/Math.PI;
			
			/*cssファイルの値を書き換える*/
			$('#galaCircle').css('width', gala_Menseki_Kara_Chokkei*15+"px");
			$('#galaCircle').css('height', gala_Menseki_Kara_Chokkei*15+"px");
			$('#smaCircle').css('width', sma_Menseki_Kara_Chokkei*15+"px");
			$('#smaCircle').css('height', sma_Menseki_Kara_Chokkei*15+"px");
        }
    });
    $('#yearSlider').slider({
        max: 7,
        min: 0,
        orientation: "horizontal",
        step: 1,
        value: 0,
        range: "min",

        slide: function (select, handleIndex) {//yearスライダーが動いた時にこの中が実行される
			
			yearslider = handleIndex.value;//スライダーの現在位置を記録
			
			var showYear = handleIndex.value+2011;//表示用にスライダーの数値を改造（[0~7]→[2011~2018]）
			document.getElementById("year").innerText = "year : " + showYear;//表示
			
			/*普及率の数字が描画される円の面積に反映されるようにする計算*/
			var gala_Menseki_Kara_Chokkei = 2*Math.sqrt(gala[ageslider][yearslider])/Math.PI;
			var sma_Menseki_Kara_Chokkei = 2*Math.sqrt(sma[ageslider][yearslider])/Math.PI;
			
			/*cssファイルの値を書き換える*/
			$('#galaCircle').css('width', gala_Menseki_Kara_Chokkei*15+"px");
			$('#galaCircle').css('height', gala_Menseki_Kara_Chokkei*15+"px");
			$('#smaCircle').css('width', sma_Menseki_Kara_Chokkei*15+"px");
			$('#smaCircle').css('height', sma_Menseki_Kara_Chokkei*15+"px");
        }
    });
});

